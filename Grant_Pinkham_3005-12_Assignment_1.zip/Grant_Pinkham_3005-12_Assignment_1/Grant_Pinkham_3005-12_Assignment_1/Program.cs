﻿// Grant Pinkham
// CSCI 3005-12
// Assignment 1
using System;
namespace Pig
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("\n==================================\n========= Welcome to Pig =========\n=== Developed by Grant Pinkham ==\nOink Oink Oink Oink Oink Oink Oink\n==================================\n");
            Game Pig = new Game();
            Pig.SetupDie();
            Pig.SetupMaxPoints();
            Pig.SetupPlayer1();
            Pig.SetupPlayer2();
            Pig.PlayGame();
        }
    }
}