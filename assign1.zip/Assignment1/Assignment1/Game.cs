// Grant Pinkham
// CSCI 3005
// Assignment 1
using System;
namespace Pig
{
    public class Die
    {
        private int numSides;
        private int currentValue;
        private Random rand;
        public Die(int numSides)
        {
            if (numSides < 4 || numSides > 20)
            {
                throw new ArgumentException($"WARNING: {numSides} is not a valid value. Please try again.");
            }
            this.numSides = numSides;
            this.currentValue = 1;
            this.rand = new Random();
        }
        public void roll()
        {
            currentValue = rand.Next(1, numSides + 1);
        }
        public int GetCurrentValue()
        {
            return currentValue;
        }
    }
    public class Player
    {
        private string name;
        private int score;
        private bool winner;
        public Player(string name)
        {
            this.name = name;
            if (string.IsNullOrEmpty(name)) 
            {
                throw new ArgumentException("Name is invalid");
            }
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("Name is invalid");
            }
            this.score = 0;
            this.winner = false;
        }
        public string GetName()
        {
            return this.name;
        }
        public void SetScore(int score)
        {
            this.score = score;
        }
        public int GetScore()
        {
            return this.score;
        }
        public void SetWinner(bool winner)
        {
            this.winner = winner;
        }
        public bool IsWinner()
        {
            return this.winner;
        }
        public override string ToString()
        {
            return this.name;
        }
    }
    public class Game
    {
        private Die gameDie;
        private Player player1;
        private Player player2;
        private int maxPoints;
        public Game()
        {
            this.gameDie = null;
            this.player1 = null;
            this.player2 = null;
            this.maxPoints = 0;
        }
        public void SetupDie()
        {
            Console.WriteLine("How many sides on the die (4 - 20): ");
            int enteredDie = int.Parse(Console.ReadLine());
            Console.WriteLine("");
            while ((enteredDie < 4) || (enteredDie > 20))
            {
                Console.WriteLine($"WARNING: {enteredDie} is not a valid value. Please try again.");
                enteredDie = int.Parse(Console.ReadLine());
                Console.WriteLine("");
            }
            gameDie = new Die(enteredDie);
        }
        public void SetupMaxPoints()
        {
            Console.WriteLine("What are the max points for the game: ");
            maxPoints = int.Parse(Console.ReadLine());
            Console.WriteLine("");
            while (maxPoints <= 0)
            {
                Console.WriteLine($"WARNING: {maxPoints} is not a valid value. Please try again.");
                maxPoints = int.Parse(Console.ReadLine());
                Console.WriteLine("");
            }
        }
        public void SetupPlayer1()
        {
            Console.WriteLine("What is player 1's name: ");
            string playerOneInputtedName = Console.ReadLine();
            Console.WriteLine("");
            while (string.IsNullOrEmpty(playerOneInputtedName))
            {
                Console.WriteLine($"WARNING: Player name needs at least one character. Please try again.");
                Console.WriteLine("What is player 1's name: ");
                playerOneInputtedName = Console.ReadLine();
                Console.WriteLine("");
            }
            Player playerOneName = new Player(playerOneInputtedName);
            player1 = playerOneName;
        }
        public void SetupPlayer2()
        {
            Console.WriteLine("What is player 2's name: ");
            string player2InputName = Console.ReadLine();
            Console.WriteLine("");
            while (string.IsNullOrEmpty(player2InputName))
            {
                Console.WriteLine($"WARNING: Player name needs at least one character. Please try again.");
                Console.WriteLine("What is player 2's name: ");
                player2InputName = Console.ReadLine();
                Console.WriteLine("");
            }
            Player playerTwoName = new Player(player2InputName);
            player2 = playerTwoName;
        }
        public void PlayGame()
        {
            Console.WriteLine("=== Oink! Let's play Pig! Oink! ===");
            Console.WriteLine("");
            String whichPlyrRolling = player1.GetName();
            bool pl1Turn, pl2Turn;
            if (whichPlyrRolling == player1.GetName())
            {
                pl1Turn = true;
                pl2Turn = false;
            }
            else
            {
                whichPlyrRolling = player2.GetName();
                pl2Turn = true;
                pl1Turn = false;
            }
            while (pl1Turn == true || pl2Turn == true)
            {
                if (player1.GetScore() >= maxPoints)
                {
                    player1.SetWinner(true);
                    break;
                } else if (player2.GetScore() >= maxPoints)
                {
                    player2.SetWinner(true);
                    break;
                }
                if (pl1Turn == true && pl2Turn == false)
                {
                    int beforeQuestionSum, originalScore, sumWhileInChosen1;
                    Console.WriteLine($"Current player: {player1}");
                    Console.WriteLine($"Current score: {player1.GetScore()}");
                    Console.WriteLine("");
                    originalScore = player1.GetScore();
                    gameDie.roll();
                    Console.WriteLine($"You rolled a {gameDie.GetCurrentValue()}");
                    beforeQuestionSum = gameDie.GetCurrentValue() + originalScore;
                    if (gameDie.GetCurrentValue() != 1)
                    {
                        player1.SetScore(beforeQuestionSum);
                    } else if (gameDie.GetCurrentValue() == 1)
                    {
                        player1.SetScore(originalScore);
                    }
                    int rollOrHold = 0;
                    while (gameDie.GetCurrentValue() != 1 && rollOrHold != 2)
                    {
                        Console.WriteLine("Do you want to roll or hold (1 = roll, 2 = hold): ");
                        rollOrHold = int.Parse(Console.ReadLine());
                        Console.WriteLine("");
                        if (rollOrHold == 1)
                        {
                            gameDie.roll();
                            Console.WriteLine($"You rolled a {gameDie.GetCurrentValue()}");
                            sumWhileInChosen1 = gameDie.GetCurrentValue() + player1.GetScore();
                            player1.SetScore(sumWhileInChosen1);
                            if (gameDie.GetCurrentValue() == 1)
                            {
                                player1.SetScore(originalScore);
                            }
                        }
                    }
                    if (rollOrHold == 2)
                    {
                        Console.WriteLine($"{player1}'s score is now {player1.GetScore()}");
                        Console.WriteLine("");
                        pl2Turn = true;
                        pl1Turn = false;
                        if (player1.GetScore() < maxPoints)
                        {
                            Console.WriteLine("----- Next player's turn ----");
                            Console.WriteLine("");
                        }
                    }
                    if (gameDie.GetCurrentValue() == 1)
                    {
                        Console.WriteLine($"Sorry you rolled a 1. Your turn is over.");
                        Console.WriteLine("");
                        Console.WriteLine($"{player1}'s score is now {player1.GetScore()}");
                        Console.WriteLine("");
                        pl2Turn = true;
                        pl1Turn = false;
                        if (player1.GetScore() < maxPoints)
                        {
                            Console.WriteLine("----- Next player's turn ----");
                            Console.WriteLine("");
                        }
                    }
                } else if (pl2Turn = true && pl1Turn == false)
                {
                    int beforeQuestionSum, originalScore, sumWhileInChosen1;
                    Console.WriteLine($"Current player: {player2}");
                    Console.WriteLine($"Current score: {player2.GetScore()}");
                    Console.WriteLine("");
                    originalScore = player2.GetScore();
                    gameDie.roll();
                    Console.WriteLine($"You rolled a {gameDie.GetCurrentValue()}");
                    beforeQuestionSum = gameDie.GetCurrentValue() + originalScore;
                    if (gameDie.GetCurrentValue() != 1)
                    {
                        player2.SetScore(beforeQuestionSum);
                    } else if (gameDie.GetCurrentValue() == 1)
                    {
                        player2.SetScore(originalScore);
                    }
                    int rollOrHold = 0;
                    while (gameDie.GetCurrentValue() != 1 && rollOrHold != 2)
                    {
                        Console.WriteLine("Do you want to roll or hold (1 = roll, 2 = hold): ");
                        rollOrHold = int.Parse(Console.ReadLine());
                        Console.WriteLine("");
                        if (rollOrHold == 1)
                        {
                            gameDie.roll();
                            Console.WriteLine($"You rolled a {gameDie.GetCurrentValue()}");
                            sumWhileInChosen1 = gameDie.GetCurrentValue() + player2.GetScore();
                            player2.SetScore(sumWhileInChosen1);
                            if (gameDie.GetCurrentValue() == 1)
                            {
                                player2.SetScore(originalScore);
                            }
                        }
                    }
                    if (rollOrHold == 2)
                    {
                        Console.WriteLine($"{player2}'s score is now {player2.GetScore()}");
                        Console.WriteLine("");
                        pl2Turn = false;
                        pl1Turn = true;
                        if (player2.GetScore() < maxPoints)
                        {
                            Console.WriteLine("----- Next player's turn ----");
                            Console.WriteLine("");
                        }
                    }
                    if (gameDie.GetCurrentValue() == 1)
                    {
                        Console.WriteLine($"Sorry you rolled a 1. Your turn is over.");
                        Console.WriteLine("");
                        Console.WriteLine($"{player2}'s score is now {player2.GetScore()}");
                        Console.WriteLine("");
                        pl2Turn = false;
                        pl1Turn = true;
                        if (player2.GetScore() < maxPoints)
                        {
                            Console.WriteLine("----- Next player's turn ----");
                            Console.WriteLine("");
                        }
                    }
                }
            }
            if (player1.IsWinner() == true)
            {
                Console.WriteLine($"----- Winner winner chicken dinner ----");
                Console.WriteLine("");
                Console.WriteLine($"Player 1, {player1}, is the winner with {player1.GetScore()} points!");
            } else if (player2.IsWinner() == true)
            {
                Console.WriteLine($"----- Winner winner chicken dinner ----");
                Console.WriteLine("");
                Console.WriteLine($"Player 2, {player2}, is the winner with {player2.GetScore()} points!");
            }
        }
    }
}