﻿// Grant Pinkham
// CSCI 3005
// Assignment 2
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
namespace BullAndCow
{
    public class Secret
    {
        private int minTargetNum = 0;
        private int maxTargetNum = 10;
        private int bulls;
        private int cows;
        private Random rand = new Random();
        private int[] _target = {3,4,5,6,7,8,9,10};
        public string Target
        {
            get
            {
                string returnString = "";
                for (int i = 0; i < _target.Length; i++)
                {
                    returnString += _target[i];
                }
                return returnString;
            }
        }
        public int Length
        {
            get
            {
                return _target.Length;
            }
        }
        public int Bulls
        {
            get
            {
                return bulls;
            }
        }
        public int Cows
        {
            get 
            {
                return cows;
            }
        }
        public Secret(int numDigits)
        {
            bulls = 0;
            cows = 0;
            if (numDigits < 3 || numDigits > 10)
            {
                throw new ArgumentException("WARNING: out of range");
            }
            _target = new int[numDigits];
            for (int i = minTargetNum; i < _target.Length; i++)
            {
                _target[i] = rand.Next(minTargetNum, maxTargetNum);
                for (int j = minTargetNum; j < i; j++)
                {
                    if (_target[j] == _target[i])
                    {
                        i--;
                        break;
                    }
                }
            }
        }
        public void CheckGuess(int[] guess)
        {
            bulls = 0;
            cows = 0;
            for (int i = 0; i < _target.Length; i++)
            {
                if (guess[i] == _target[i])
                {
                    bulls++;
                }
            }
            for (int i = 0; i < guess.Length; i++)
            {
                for (int j = 0; j < guess.Length; j++)
                {
                    if (guess[i] == _target[j] && i != j)
                    {
                        cows++;
                    } 
                }
            }
        }
    }
    class HighScoreList
    {
        private List<int> _scores;
        string fileName = @"C:\data\highscorelist.txt";
        public HighScoreList()
        {
            Load();
        }
        public string HighScoreTable
        {
            get
            {
                Console.WriteLine("Digits : Best Score");
                int startIndex = 3;
                string emptyString = "";
                foreach (int i in _scores)
                {
                    Console.WriteLine($"{startIndex} : {i}");
                    startIndex++;
                }
                return emptyString;
            }
        }
        private void Load()
        {
            _scores = new List<int>();
            try
            {
                using StreamReader readFile = new StreamReader(fileName);
                string readOrBreak = readFile.ReadLine();
                int num = 0;
                while (true)
                {
                    _scores[num] = Int32.Parse(readOrBreak);
                    if ((readOrBreak = readFile.ReadLine()) == null) {
                        break;
                    }
                }
                readFile.Close();
            }
            catch (Exception)
            {
                for (int i = 0; i < 8; i++)
                {
                    _scores.Add(1000000);
                }
            }
        }
        private void Save()
        {
            using StreamWriter writeFile = new StreamWriter(fileName);
            try
            {
                for (int i = 0; i < _scores.Count; i++)
                {
                    writeFile.WriteLine(_scores[i]);
                }
            }
            catch (Exception msg)
            {
                Console.WriteLine(msg);
            }
            writeFile.Close();
        }
        public void UpdateHighScoreForDigit(int digits, int numGuesses)
        {
            digits -= 3;
            if (numGuesses < _scores[digits])
            {
                _scores[digits] = numGuesses;
                Save();
            }
        }
    }
    public class Game
    {
        private Secret _secret;
        private HighScoreList _highScoreList;
        private bool _doCheat;
        public Game()
        {
            _secret = null;
            _doCheat = false;
            _highScoreList = new HighScoreList();
        }
        public void CreateSecret()
        {
            Console.WriteLine("-----------------------------------\n---   Welcome to Bull and Cow   ---\n--- Developed by Grant Pinkham  ---\n-----------------------------------\n");
            bool flag = true;
            while (flag)
            {
                try
                {
                    Console.WriteLine("How many digits for this game (3 - 10)?");
                    int userEnteredDigits = Int32.Parse(Console.ReadLine());
                    if (userEnteredDigits < 3 || userEnteredDigits > 10)
                    {
                        Console.WriteLine("\nWARNING: Number of digits out of range. Try again.\n");
                    }
                    else
                    {
                        _secret = new Secret(userEnteredDigits);
                        Console.WriteLine("");
                        break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("\nWARNING: Not a number. Try again.\n");
                }
            }
        }
        public void SetupCheat()
        {
            while (true)
            {
                Console.WriteLine("Do you want to cheat (Y/N)?");
                string yesOrNo = Console.ReadLine();
                yesOrNo = yesOrNo.ToLower();
                if (yesOrNo == "y")
                {
                    _doCheat = true;
                    Console.WriteLine("");
                    break;
                }
                else if (yesOrNo == "n")
                {
                    Console.WriteLine("");
                    break;
                }
            }
        }
        public void Play()
        {
            if (_secret == null)
            {
                throw new NullReferenceException();
            }
            int howManyGuessesTotal = 0;
            bool flag = true;
            int[] tempArr = new int[_secret.Length];
            while (flag)
            {
                if (_doCheat == true)
                {
                    Console.WriteLine($"Secret = {_secret.Target} CHEATER!!!");
                }
                Console.WriteLine("Enter guess: ");
                howManyGuessesTotal++;
                for (int i = 0; i <= tempArr.Length - 1; i++)
                {
                    Console.Write("Position " + (i + 1) + ":");
                    try
                    {
                        tempArr[i] = Int32.Parse(Console.ReadLine());
                    }
                    catch (FormatException msg)
                    {

                    }
                }
                _secret.CheckGuess(tempArr);
                Console.WriteLine("\nBulls: " + _secret.Bulls + " Cows: " + _secret.Cows);
                if (_secret.Bulls == tempArr.Length)
                {
                    Console.WriteLine("It took you " + howManyGuessesTotal + " guess(es)");
                    flag = false;
                    _highScoreList.UpdateHighScoreForDigit(_secret.Length, howManyGuessesTotal);
                }
            }
            Console.WriteLine("\nBulls: " + _secret.Bulls + " Cows: " + _secret.Cows + "\n");
        }
        public void ShowHighScores()
        {
            Console.WriteLine("***************\n* High Scores *\n***************\n");
            Console.WriteLine(_highScoreList.HighScoreTable);
        }
    }
}




