﻿// Grant Pinkham
// CSCI 3005
// Assignment 2
using BullAndCow;
namespace BullAndCow {
    class Program
    {
        public static void Main(string[] args)
        {
            Game bullAndCow = new Game();
            bullAndCow.CreateSecret();
            bullAndCow.SetupCheat();
            bullAndCow.Play();
            bullAndCow.ShowHighScores();
        }
    }
}